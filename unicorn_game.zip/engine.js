// Use local storage to keep track of progress
// add time for each power moon

const BUFFER_WIDTH 		= 700;
const BUFFER_HEIGHT		= 400;
const SPRITE_SIZE 		= 72;
const requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
window.requestAnimationFrame = requestAnimationFrame;

// globals
var gameTimeRemaining	= 0;
var gCurrentMap 		= 0;
var gGameState 			= 0; // 0 = start screen, 1 = in-game, 3 = lose life, 4 = win level, 5 = game over

var Animation = function(frame_set, delay) {
	this.count 			= 0;		// Counts the number of game cycles since the last frame change.
	this.delay 			= delay;	// The number of game cycles to wait until the next frame change.
	this.frame 			= 0;		// The value in the sprite sheet of the sprite image / tile to display.
	this.frame_index 	= 0;		// The frame's index in the current animation frame set.
	this.frame_set 		= frame_set;// The current animation frame set that holds sprite tile values.
};

spriteSheet = {
	frame_sets:	[[0, 1], [2, 3], [4, 5], [6, 7]],// standing still left, walk right, walk left, standing still right
	image:		new Image()
};

Animation.prototype = {
	change:function(frame_set, delay = 20) {
		if (this.frame_set != frame_set) {	// If the frame set is different:
			this.count 			= 0;		// Reset the count.
			this.delay 			= delay;	// Set the delay.
			this.frame_index 	= 0;		// Start at the first frame in the new frame set.
			this.frame_set 		= frame_set;// Set the new frame set.
			this.frame 			= this.frame_set[this.frame_index];// Set the new frame value.
		}
	},

	/* Call this on each game cycle. */
	update:function() {
		this.count++; // keep track of how many cycles have passed since the last frame change.
		if (this.count >= this.delay) { // if enough cycles have passed, we change the frame.
			this.count = 0; // reset the count.
			this.frame_index = (this.frame_index == this.frame_set.length - 1) ? 0 : this.frame_index + 1;
			this.frame = this.frame_set[this.frame_index];// Change the current frame value.
		}
	}
};

controller = {
	left:	false,
	right:	false,
	up:		false,
	down:	false,

	keyUpDown: function(event) {
		var keyState = (event.type == "keydown") ? true : false;
		switch(event.keyCode) {
			case 32: controller.up		=	keyState; break; // space bar
			case 37: controller.left	= 	keyState; break; // left key
			case 38: controller.up		= 	keyState; break; // up key
			case 39: controller.right	= 	keyState; break; // right key
			case 40: controller.down	= 	keyState; break; // right key
		}
	}
};

// render the map to the buffer and output to screen
display = {
	buffer:			document.createElement("canvas").getContext("2d"),
	context:		document.getElementById("cnv").getContext("2d"),

	render:function() {
		this.buffer.clearRect(0, 0, this.buffer.canvas.width, this.buffer.canvas.height);
		this.context.clearRect(0, 0, this.context.canvas.width, this.context.canvas.height);

		for (let i=0; i < game.world.map.length; i++) {
			for (j=0; j<game.world.map[i].length; j++) {
				switch(game.world.map[i][j]) {
					case 11: // Soil & grass tile
					var	srcX = 270; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 12: // Rock tile
					var	srcX = 45; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 13: // Stone tile
					var	srcX = 405; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 14: // Dirt tile
					var	srcX = 360; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 20: // Coin tile
					var	srcX = 0; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 21: // Moon tile
					var	srcX = 135; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 30: // Create tile
					var	srcX = 450; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				}
			}
		}

		// game score and time
		this.buffer.font = "bold 18px 'Courier'";
		this.buffer.fillStyle = 'rgb(255,30,0)';
		this.buffer.fillText("Coins: " + game.player.coins + '/' + game.world.coins, 10, 20);
		this.buffer.fillText("Time: " + gameTimeRemaining, 160, 20);
		// this.buffer.fillText("Moons: " + game.player.moons + '/' + game.world.moons, 160, 20);

		// draw the player
		display.buffer.drawImage(spriteSheet.image, game.player.animation.frame * SPRITE_SIZE, 0, SPRITE_SIZE, SPRITE_SIZE, Math.floor(game.player.x), Math.floor(game.player.y), game.player.width, game.player.height);
		
		// render the buffer to the canvas
		this.context.drawImage(this.buffer.canvas, 0, 0, BUFFER_WIDTH, BUFFER_HEIGHT, 0, 0, this.context.canvas.width, this.context.canvas.height);
	},
	resize: function(event) {
		// basic setup and initialization
		display.buffer.canvas.width = BUFFER_WIDTH;
		display.buffer.canvas.height = BUFFER_HEIGHT;
		display.context.canvas.width = window.innerWidth;
		display.context.canvas.height = window.innerHeight;
	},
	splashScreen: () => {
		display.buffer.drawImage(splashScreenImg, 100, 50, 500, 300);
		display.context.drawImage(display.buffer.canvas, 0, 0, BUFFER_WIDTH, BUFFER_HEIGHT, 0, 0, display.context.canvas.width, display.context.canvas.height);
	},
	startScreen: function() {
		// render the buffer to the canvas
		this.buffer.beginPath();

		//Box 1
		this.buffer.fillStyle = 'yellow';
		this.buffer.fillRect(50, 50, 100, 100);
		this.buffer.font = "Bold 18px 'Courier'";
		this.buffer.fillStyle = 'rgb(255,30,0)';
		this.buffer.fillText('Level 1', 65, 105);

		this.buffer.fillStyle = 'red';
		this.buffer.fillRect(200,50,100,100);
		this.buffer.font = "Bold 18px 'Courier'";
		this.buffer.fillStyle = 'rgb(30,30,255)';
		this.buffer.fillText('Level 2', 215, 105);

		this.buffer.fillStyle = 'green';
		this.buffer.fillRect(350,50,100,100);
		this.buffer.font = "Bold 18px 'Courier'";
		this.buffer.fillStyle = 'rgb(30,255,30)';
		this.buffer.fillText('Level 3', 365, 105);

		this.buffer.stroke();

		// // game score and time
		// this.buffer.font = "bold 18px 'Courier'";
		// this.buffer.fillStyle = 'rgb(255,30,0)';
		// this.buffer.fillText('Time: ' + gameTimeRemaining, 160, 20);

		this.context.drawImage(this.buffer.canvas, 0, 0, BUFFER_WIDTH, BUFFER_HEIGHT, 0, 0, this.context.canvas.width, this.context.canvas.height);
	}
};

game = {
	gameObjectArr: [],
	generateCollisionObjects: function() {
		for (let i = 0; i < game.world.map.length; i++) {
			const row = game.world.map[i]
			for (let j = 0; j < row.length; j++) {
				if (row[j] > 10 && row[j] < 20) {
					let count = j + 1;
					while (count < row.length && row[count] === row[j]) { count += 1 }
					this.gameObjectArr.push({
						x: j * this.world.tile_size,
						y: i * this.world.tile_size,
						width: this.world.tile_size * (count - j),
						height: this.world.tile_size,
						value: row[j]
					});
					j = count - 1;
				}
			}
		}
	},
	generateGameObjects: function() {
		for (let i = 0; i < game.world.map.length; i++) {
			for (let j = 0; j < game.world.map[i].length; j++) {
				if (game.world.map[i][j] >= 20) {
					this.gameObjectArr.push({
						x: j * this.world.tile_size,
						y: i * this.world.tile_size,
						width: this.world.tile_size,
						height: this.world.tile_size,
						value: game.world.map[i][j]
					});
				}
			}
		}
	},
	init: function() {
		// game.world = gameMaps[gCurrentMap];
		// display.resize();
		// gameBgSnd.volume = 0.3;
		// gameBgSnd.play();
		// gameTimeRemaining = game.world.time;
		// GAME_START = performance.now();
		// this.generateCollisionObjects();
		// this.generateGameObjects();
		// game.loop();
	},
	removeGameObjects: function(player, gameObject) {
		// player.velocity_y = 0; //testing only
		game.world.map[gameObject.y / game.world.tile_size][gameObject.x / game.world.tile_size] = 10
		gameObject.value = 10;
		delete gameObject.width, gameObject.height;
	},
	collision: function(player, object) { // rect1 = player, object = object
		var w = 0.5 * (player.width + object.width);
		var h = 0.5 * (player.height + object.height);
		var dx = (player.x + player.width / 2) - (object.x + object.width / 2);
		var dy = (player.y + player.height / 2) - (object.y + object.height / 2);

		if (Math.abs(dx) <= w && Math.abs(dy) <= h) { /* collision! */
			var wy = w * dy;
			var hx = h * dx;

			if (wy > hx) {
				if (wy > -hx) { // top of player collides with object
					return {
						player: player,
						object: object,
						collisionSide: 1 // 1=top, 2=right, 3=bottom, 4=left
					}
				} else { // left of player collides with object
					return {
						player: player,
						object: object,
						collisionSide: 4 // 1=top, 2=right, 3=bottom, 4=left
					}
				}
			} else {
				if (wy > -hx) { // right of player collides with object
					return {
						player: player,
						object: object,
						collisionSide: 2 // 1=top, 2=right, 3=bottom, 4=left
					}
				} else { // bottom of player collides with object
					return {
						player: player,
						object: object,
						collisionSide: 3 // 1=top, 2=right, 3=bottom, 4=left
					}
				}
			}
		}
	},
	player: {
		animation:	new Animation(), // You don't need to setup Animation right away.
		color:		"#880000",
		width:		45,
		height:		45,
		x:			0,
		y:			0,
		old_x:		0,
		old_y:		0,
		velocity_x:	11,
		velocity_y:	0,
		jumping:	true,
		lives:		5,
		coins:		0,
		moons:		0,
		direction:	0 // 0=right, 1=left
	},
	update: function() {
		// check and update game time
		var CURRENT_TIME = performance.now();
		if (gameTimeRemaining <= 0) {
			gameTimeRemaining = 0;
			gGameState = 2; 
			return;
		} else {
			let timeTaken = Math.floor(Math.floor(CURRENT_TIME)/1000 - Math.floor(GAME_START)/1000);
			gameTimeRemaining = (game.world.time - timeTaken);
		}

		if (controller.left) {
			game.player.velocity_x -= 0.45;
			game.player.animation.change(spriteSheet.frame_sets[2], 12);
			game.player.direction = 1;

		} else if (controller.right) {
			game.player.velocity_x += 0.45;
			game.player.animation.change(spriteSheet.frame_sets[1], 12);
			game.player.direction = 0;
		}

		/* If you're just standing still, change the animation to standing still. */
		if (!controller.left && !controller.right) {
			if(game.player.direction == 0 ) { // player was moving right
				game.player.animation.change(spriteSheet.frame_sets[0], 18);
			} else {
				game.player.animation.change(spriteSheet.frame_sets[3], 18);
			}
		}

		if (controller.up && !game.player.jumping) {
			game.player.velocity_y = -22;
			game.player.jumping = true;
			playerJumpSnd.volume = 0.6;
			playerJumpSnd.play();
		}

		game.player.old_x = game.player.x;// Set the old position to the current position
		game.player.old_y = game.player.y;// before we update the current position, thus making it current
		game.player.velocity_y += 1.45;
		game.player.x += game.player.velocity_x;// Update the current position
		game.player.y += game.player.velocity_y;

		// Do collision detection and response with the boundaries of the screen.
		if (game.player.x < 0) {
			game.player.velocity_x = 0;
			game.player.old_x = game.player.x = 0;
		} else if (game.player.x + game.player.width > display.buffer.canvas.width) {
			game.player.velocity_x = 0;
			game.player.x = game.player.old_x = display.buffer.canvas.width - game.player.width;
		}

		if (game.player.y < 0) {
			game.player.velocity_y = 0;
			game.player.old_y = game.player.y = 0;
		} else if (game.player.y + game.player.height > display.buffer.canvas.height) {
			game.player.velocity_y = 0;
			game.player.old_y = game.player.y = display.buffer.canvas.height - game.player.height;
			game.player.jumping = false;
		}

		//*********************************
		//** main collision detection start
		//*********************************

		// switch by colData.object.value??
		for (let c=0; c<game.gameObjectArr.length; c++) {
			let colData = game.collision(game.player, game.gameObjectArr[c]);
			if (colData !== undefined) {
				switch (colData.object.value) {
					case 20: // gold coin
						switch (colData.collisionSide) { // 1=top, 2=left, 3=bottom, 4=right
							case 1: case 2: case 3: case 4:
								game.removeGameObjects(colData.player, colData.object);
								++game.player.coins;
								coinSnd.play();
								break;
							default:
								break;
						}
					break;
					case 21: // power moon
						switch (colData.collisionSide) { // 1=top, 2=left, 3=bottom, 4=right
							case 1: case 2: case 3: case 4:
								game.removeGameObjects(colData.player, colData.object);
								game.world.time += 5;
							break;
						}
					break;
					case 30: // crate
						switch (colData.collisionSide) { // 1=top, 2=left, 3=bottom, 4=right
							case 1: case 2:case 4: break;
							case 3:
								colData.player.velocity_y = 0;
								// game.removeGameObjects(colData.player, colData.object);
								colData.player.jumping = false;
								colData.player.y = colData.object.y - colData.player.height;
							break;
						}
					break;
					default: // main object collision detection
						switch (colData.collisionSide) { // 1=top, 2=right, 3=bottom, 4=left
							case 1:
								colData.player.velocity_y = 0;
								colData.player.y = colData.object.y + colData.object.height;
								colData.player.jumping = true;
								break;
							break;
							case 2:
								colData.player.velocity_x = 0;
								colData.player.x = colData.object.x + colData.object.width;
								break;
							break;
							case 3:
								colData.player.velocity_y = 0;
								colData.player.y = colData.object.y - colData.player.height;
								colData.player.jumping = false;
								break;
							break;
							case 4:
								colData.player.velocity_x = 0;
								colData.player.x = colData.object.x - colData.player.width;
								break;
							break;
						}
						break;
				}
			}
		}

		//*********************************
		//** main collision detection end
		//*********************************

		// add friction to the player object
		game.player.velocity_x *= 0.9;
		game.player.velocity_y *= 0.9;

		// update the player object display
		// game.player.animation.update();
	},
	loop:function() {
		switch (gGameState) {
			case 0:
				display.resize();
				display.splashScreen();
				requestAnimationFrame(game.loop);
				break;
			case 1:
				display.resize();
				display.startScreen();
				requestAnimationFrame(game.loop);
				break;
			case 2:
				game.update();
				game.player.animation.update();
				requestAnimationFrame(game.loop);
				display.render();
				break;
			default:
				break;
		}
	}
};

window.addEventListener("resize", display.resize);
window.addEventListener("keydown", controller.keyUpDown);
window.addEventListener("keyup", controller.keyUpDown);

// document.getElementById('cnv').addEventListener("mousemove", (evt) => {
// 	let cnv = document.getElementById('cnv');
// 	let x = evt.clientX - cnv.offsetLeft;
// 	let y = evt.clientY - cnv.offsetTop;
// 	// console.log(x + ' ' + y);
// });

document.getElementById('cnv').addEventListener("mouseup", (evt) => {
	if (gGameState == 0) {
		gGameState = 1;
	} else if (gGameState == 1) {		
		let cnv = document.getElementById('cnv');
		let x = evt.clientX - cnv.offsetLeft;
		let y = evt.clientY - cnv.offsetTop;

		if (x > 100 && x < 300 && y > 90 && y < 270) {
			document.getElementById('cnv').style.cursor = 'none';
			gCurrentMap = 0;
			gGameState = 2;

			game.world = gameMaps[gCurrentMap];
			display.resize();
			gameBgSnd.volume = 0.3;
			gameBgSnd.play();
			gameTimeRemaining = game.world.time;
			GAME_START = performance.now();
			game.generateCollisionObjects();
			game.generateGameObjects();
		} else if (x > 400 && x < 600 && y > 90 && y < 270) {
			document.getElementById('cnv').style.cursor = 'none';
			gCurrentMap = 1;
			gGameState = 2;

			game.world = gameMaps[gCurrentMap];
			display.resize();
			gameBgSnd.volume = 0.3;
			gameBgSnd.play();
			gameTimeRemaining = game.world.time;
			GAME_START = performance.now();
			game.generateCollisionObjects();
			game.generateGameObjects();
		} else if (x > 700 && x < 900 && y > 90 && y < 270) {
			document.getElementById('cnv').style.cursor = 'none';
			gCurrentMap = 2;
			gGameState = 2;

			game.world = gameMaps[gCurrentMap];
			display.resize();
			gameBgSnd.volume = 0.3;
			gameBgSnd.play();
			gameTimeRemaining = game.world.time;
			GAME_START = performance.now();
			game.generateCollisionObjects();
			game.generateGameObjects();
		}
	}
});

var gameSprites = new Image();
var splashScreenImg = new Image();
gameSprites.src = 'images/gameSprites.png';
splashScreenImg.src = 'images/splash.png';
spriteSheet.image.src 	= "images/unicorn.png";// Start loading the image.

var playerJumpSnd = new Audio('sounds/jump.mp3');
var powerupSnd = new Audio('sounds/powerup.mp3');
var coinSnd = new Audio('sounds/coin.mp3');
var gameBgSnd = new Audio('sounds/bgMusic.mp3');

function startGame () {
	// display.resize();
	// display.render();
	game.loop();
}