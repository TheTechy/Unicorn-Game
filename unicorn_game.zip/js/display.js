// render the map to the buffer and output to screen
display = {
	buffer:			document.createElement("canvas").getContext("2d"),
	context:		document.getElementById("cnv").getContext("2d"),

	render:function() {
		this.buffer.clearRect(0, 0, this.buffer.canvas.width, this.buffer.canvas.height);
		this.context.clearRect(0, 0, this.context.canvas.width, this.context.canvas.height);

		for (let i=0; i < game.world.map.length; i++) {
			for (j=0; j<game.world.map[i].length; j++) {
				switch(game.world.map[i][j]) {
					case 11: // Soil & grass tile
					var	srcX = 270; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 12: // Rock tile
					var	srcX = 45; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 13: // Stone tile
					var	srcX = 405; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 14: // Dirt tile
					var	srcX = 360; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 20: // Coin tile
					var	srcX = 0; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 21: // Moon tile
					var	srcX = 135; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				case 30: // Create tile
					var	srcX = 450; srcY = 0; srcW = 45; srcH = 45;
					destX = j * game.world.tile_size;
					destY = i * game.world.tile_size;
					destW = game.world.tile_size;
					destH = game.world.tile_size;
					display.buffer.drawImage(gameSprites, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
				break;
				}
			}
		}

		// game score and time
		this.buffer.font = "bold 18px 'Courier'";
		this.buffer.fillStyle = 'rgb(255,30,0)';
		this.buffer.fillText("Coins: " + game.player.coins + '/' + game.world.coins, 10, 20);
		this.buffer.fillText("Time: " + gameTimeRemaining, 160, 20);
		this.buffer.fillText("Lives: " + game.player.lives, 280, 20);
		// this.buffer.fillText("Moons: " + game.player.moons + '/' + game.world.moons, 160, 20);

		// draw the player
		display.buffer.drawImage(spriteSheet.image, game.player.animation.frame * SPRITE_SIZE, 0, SPRITE_SIZE, SPRITE_SIZE, Math.floor(game.player.x), Math.floor(game.player.y), game.player.width, game.player.height);
		
		// render the buffer to the canvas
		this.context.drawImage(this.buffer.canvas, 0, 0, BUFFER_WIDTH, BUFFER_HEIGHT, 0, 0, this.context.canvas.width, this.context.canvas.height);
	},
	resize: function(event) {
		// basic setup and initialization
		display.buffer.canvas.width = BUFFER_WIDTH;
		display.buffer.canvas.height = BUFFER_HEIGHT;
		display.context.canvas.width = window.innerWidth;
		display.context.canvas.height = window.innerHeight;
	},
	splashScreen: function() {
		display.buffer.drawImage(splashScreenImg, 100, 25, 500, 350);
		display.context.drawImage(display.buffer.canvas, 0, 0, BUFFER_WIDTH, BUFFER_HEIGHT, 0, 0, display.context.canvas.width, display.context.canvas.height);
	},
	msgScreen: (message1, message2) => {
		// render the buffer to the canvas
		display.buffer.beginPath();

		//MsgBox
		display.buffer.fillStyle = 'rgba(255,0,0,0.90)';
		display.buffer.fillRect(Math.floor(BUFFER_WIDTH / 2) - 150, Math.floor(BUFFER_HEIGHT / 2) - 50, 300, 100);
		display.buffer.font = "Bold 20px 'Courier'";
		display.buffer.fillStyle = 'rgb(10,10,10)';
		display.buffer.fillText(message1, (Math.floor(BUFFER_WIDTH / 2)), 185);
		display.buffer.fillText(message2, (Math.floor(BUFFER_WIDTH / 2)), 240);

		// display.buffer.stroke();
		display.context.drawImage(display.buffer.canvas, 0, 0, BUFFER_WIDTH, BUFFER_HEIGHT, 0, 0, display.context.canvas.width, display.context.canvas.height);
	},
	startScreen: function() {
		// render the buffer to the canvas
		this.buffer.beginPath();

		//Box 1
		this.buffer.fillStyle = 'yellow';
		this.buffer.fillRect(50, 50, 100, 100);
		this.buffer.font = "Bold 18px 'Courier'";
		this.buffer.fillStyle = 'rgb(255,30,0)';
		this.buffer.fillText('Level 1', 65, 105);

		this.buffer.fillStyle = 'red';
		this.buffer.fillRect(200,50,100,100);
		this.buffer.font = "Bold 18px 'Courier'";
		this.buffer.fillStyle = 'rgb(30,30,255)';
		this.buffer.fillText('Level 2', 215, 105);

		this.buffer.fillStyle = 'green';
		this.buffer.fillRect(350,50,100,100);
		this.buffer.font = "Bold 18px 'Courier'";
		this.buffer.fillStyle = 'rgb(30,255,30)';
		this.buffer.fillText('Level 3', 365, 105);

		this.buffer.stroke();

		// // game score and time
		// this.buffer.font = "bold 18px 'Courier'";
		// this.buffer.fillStyle = 'rgb(255,30,0)';
		// this.buffer.fillText('Time: ' + gameTimeRemaining, 160, 20);

		this.context.drawImage(this.buffer.canvas, 0, 0, BUFFER_WIDTH, BUFFER_HEIGHT, 0, 0, this.context.canvas.width, this.context.canvas.height);
	}
};