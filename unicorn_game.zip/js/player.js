player: {
	animation:	new Animation();
	color:		"#880000";
	width:		45;
	height:		45;
	x:			0;
	y:			0;
	old_x:		0;
	old_y:		0;
	velocity_x:	11;
	velocity_y:	0;
	jumping:	true;
	lives:		5;
	coins:		0;
	moons:		0;
	direction:	0
};