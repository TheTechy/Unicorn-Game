controller = {
	left:	false,
	right:	false,
	up:		false,
	down:	false,

	keyUpDown: function(event) {
		var keyState = (event.type == "keydown") ? true : false;
		switch(event.keyCode) {
			case 27: game.levelMenu();					break; // esc key
			case 32: controller.up		=	keyState;	break; // space bar
			case 37: controller.left	= 	keyState;	break; // left key
			case 38: controller.up		= 	keyState;	break; // up key
			case 39: controller.right	= 	keyState;	break; // right key
			case 40: controller.down	= 	keyState;	break; // right key
		}
	}
};